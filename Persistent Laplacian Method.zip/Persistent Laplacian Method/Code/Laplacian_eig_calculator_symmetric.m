% this function computes the weight matrix and finds the
% eigendecomposition of the Laplacian
function [V,D,Degree] = Laplacian_eig_calculator_symmetric(p,idx,dist,n_neighbors,N,sigma,power,linear_com,num_kernels,n_eigs,nL)

W= zeros(N,N,num_kernels);

for i=1:N
    for j=1:n_neighbors
           distance= dist(i,j);
        for k=1:num_kernels
            number= distance/sigma(k,1);
            number= number.^power(k,1);
            W(i,idx(i,j),k)= exp(-number);
            exp(-number);
        end
    end
end




for i=1:size(W,1)
    for k=1:num_kernels
        W(i,i,k)=0;
    end
end





D= sum(W,2);
L= zeros(N,N);
D_total= zeros(N,1);

Degree=D;


% computing the multiscale Laplacian
for k=1:num_kernels
   L= L+ linear_com(k,1)*(diag(D(:,:,k))-W(:,:,k));
   D_total= D_total+ linear_com(k,1)*D(:,:,k);
end




%Threshold = [-0.525, -0.4, -0.35,-0.33 -0.3,-0.27 -0.25,-0.23,-0.20,-0.1,0];

Min = min(L, [], 'all');%checking minimum element in matix L
Max = -min(W,[], "all");

d = Max - Min;



threshold = (p)/(nL)*d + Min;

 for i=1:N

    for j=1:n_neighbors

            if L(i,idx(i,j)) <= threshold
                L(i,idx(i,j)) = 0;

            else

                L(i,idx(i,j)) = -1; % -1 so that every elements will be -1 or zero

            end

    end

end




for i=1:N

    A=L(i,:);

    A(i)=[];

    if (size(find(A),2)==0)

       L(i,:)= -0.000000001;

    end

end

%I try to update the diagonal of L_th
L_th=L;
D = diag(L_th); %extracting the diagonal element of L_th
D1 = diag(D); %Diagonal matrix  out of D.
L_th = L_th - D1;%This will make diagnoal element of L_th zero.
size(L_th);
new_diag = -sum(L_th,2);% summing each row (diagonal elements are zero so no worries.)
D_V = new_diag;%this makes column of diagonal element
D2 = diag(D_V);%diagonal matix
L_th = L_th +D2;%th_laplacaina with updated diagonal element
%please let me know if this is not what you want me to do.
for i=1:N
    for j=1:N
        L_th_NS(i,j) = L_th(i,j)/(sqrt(D_V(i,1))*sqrt(D_V(j,1)));
    end
end


L = L_th_NS;% Normalized matrix
[V,D]= eigs(L,n_eigs,'sa');

V = real(V);
D = diag(D);


end
