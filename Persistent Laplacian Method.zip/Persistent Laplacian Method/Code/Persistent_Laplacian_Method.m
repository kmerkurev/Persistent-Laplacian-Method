function u1  = MBO(u0, Lambda, Phi, lam, C, dt, iterNum)

u = u0;
a = Phi'*u; 
b = zeros(size(Phi,2),size(u,2));
N_s=3;
Denom = 1 + (dt/N_s)*Lambda;



% MAIN ITERATION
for n = 1:iterNum
    
 

    % APPLYING THE MODIFIED DIFFUSION OPERATOR N_s TIMES
    for i=1:N_s
        for j=1:size(u,2)
            a(:,j) = (a(:,j) - (dt/N_s)*b(:,j))./Denom;
        end
    u = Phi*a;     
    b = C*(Phi'*(lam.*(u-u0)));
   
    end
    
    u = real(u);
    u1= projection_to_simplex(u);

    u = projection_to_vertex(u1);
     
end
end



% a = ft(u, Phi);
% b = ft(u.^3, Phi);
% d = zeros(L,1);
% Denom = 1 + dt*(eps*Lambda+c);
% 
% % main iteration
% for n = 1:iterNum
%     disp(n);
%     a = ((1 + dt/eps + c*dt)*a - dt*b/eps - dt*d)./Denom;
%     u = bt(a, Phi);
%     b = ft(u.^3, Phi);
%     d = c1*ft(lam.*(u-uo),Phi);
% end
