
function accuracy = main(n_neighbors_best, sigma_best, n_eigs_best, C_best, dt_best, iterNum, num, num_lab_sets, lim_1, lim_2, lim_3, lim_4, lim_5, nL)

% DATA SET
% the data.txt file should be inputed as an N by n matrix where N is the number of elements and n is the number of attributes describing each element. Below is an example data set of three moons.
% ground_truth.txt is a file of an N by 1 matrix with correct class values in the range [1,n_classes]

%INPUT
 % n_neighbors_best= best guess for the number of nearest neighbors used in graph (usually 7-100)
 % sigma_best= best guess for sigma in the Gaussian similarity weight function
 % n_eigs_best= best guss for number of eigebvectors used (usually 10-200)
 % C_best= parameter in front of fidelity term (usually 10-1000)
 % dt_best= best dt value (usually 0.01-0.1)
 % iterNum= number of iterations in the Persistent Laplacian Method (usually 10-40)
 % num= number of labeled elements per class
 % num_lab_sets= number of times the labeled set is changed (usually 1-100)
 % lim_1 through lim_5= loops used to test many different parameters
 % nL = number of Laplacian Matix


 % LOADING DATA
data = textread('data.txt');

Y= textread('ground_truth.txt');


ground_truth = Y;
size(data);
size(ground_truth);

N= size(data,1);
n_classes= size(unique(ground_truth),1);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% PARAMETERS TO TUNE
%n_neighbors, sigma, n_eigs, C, dt


% DO NOT CHANGE THESE PARAMETERS
num_kernels=1;      % number of kernels (SET TO ONE!!!)
power=2;         % the power (KEEP AT 2!!!)
linear_com= 1;     % coefficient in front of weight term (KEEP AT ONE!!!)
flag_fidelity=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% COMPUTING NEAREST NEIGHBORS
ns = createns(data,'nsmethod','kdtree');
[idx, dist] = knnsearch(ns,data,'k',200,'distance','euclidean');

%accuracy_best=0;


%loop to create nL Laplacian

    for k=0:lim_1
         for kk=0:lim_2
             for kkk=0:lim_3
                 for kkkk=0:lim_4
                     for kkkkk=0:lim_5



 % CHANGE THE FIVE LINES BELOW TO LOOP THROUGH DIFFERENT VALUES OF PARAMETERS

n_neighbors= n_neighbors_best;      % number of nearest neighbors
sigma = sigma_best;      % parameter in the weight computations
n_eigs= n_eigs_best;             % number of eigenvectors used
C = C_best;        % parameter in front of the fidelity term
dt = dt_best;         % timestep

accuracy_total=0;
for number=1:num_lab_sets
X_train = zeros(2*num,nL); %initializing the array
X_test = zeros(N-2*num,nL); %initailizing the array
%for p = 1:nL    %loop for nL laplacian


% EIGENVECTOR COMPUTATION (computing the L smallest eigenvalues and their eigenvectors of the Laplacian)
%[Phi, Lambda, Degree] = Laplacian_eig_calculator(idx,dist,n_neighbors,N,sigma,power,linear_com,num_kernels,n_eigs);
% or use the symmetric version of the Laplacian:
%[Phi, Lambda, ~] = Laplacian_eig_calculator_symmetric(p,idx,dist,n_neighbors,N,sigma,power,linear_com,num_kernels,n_eigs,nL);





% LABELED SET

% CHOOSING A CERTAIN NUMBER OF LABELED POINTS PER CLASS
% lam=1 for labeled points and lam=0 otherwise
if (flag_fidelity==0)
    lam = zeros(N,1);
    for i=1:n_classes
        x= find(ground_truth==i);
        pos = randperm(length(x));
        indices = x(pos(1:num));
        lam(indices)=1;
    end
end

 % FIDELITY TERM (CHOOSING SOME NUMBER OF LABELED POINTS RANDOMLY)
% lam=1 for labeled points and lam=0 otherwise
if (flag_fidelity==1)
    lam = zeros(N,1);
    pos = randperm(N); % shuffle indices of vector
    indices = pos(1:num_labeled_points); % take first num_labeled_points indices
    lam(indices)=1; %
end

counter=0;

% counting the number of testing (non-labeled) elements
for i=1:N
   if (lam(i,1)==0)
      counter= counter+1;
   end
end

% INITIALIZATION (RANDOM)
u0= rand(N,n_classes);

u0= projection_to_simplex(u0);

for i=1:N
    if (lam(i,1)==1)
        u0(i,:)= zeros(1,n_classes);
        u0(i,ground_truth(i,1))=1;
    end
end

for p = 1:nL  %loop for nL laplacian


% EIGENVECTOR COMPUTATION (computing the L smallest eigenvalues and their eigenvectors of the Laplacian)
%[Phi, Lambda, Degree] = Laplacian_eig_calculator(idx,dist,n_neighbors,N,sigma,power,linear_com,num_kernels,n_eigs);
% or use the symmetric version of the Laplacian:
[Phi, Lambda, ~] = Laplacian_eig_calculator_symmetric(p,idx,dist,n_neighbors,N,sigma,power,linear_com,num_kernels,n_eigs,nL);



% MAIN ALGORITHM
u1 = Persistent_Laplacian_Method(u0, Lambda, Phi, lam, C, dt, iterNum);
%Extracting training data for Regression.

j = 1;
X = zeros(n_classes*num,2);
Y = zeros(n_classes*num,1 );
    for i = 1:N

      if (lam(i,1)==1)
       X(j,:) = u1(i,:);
       Y(j,1) = (ground_truth(i,1));

       j =j+1;

      end
    end
    %Extracting testing data
k = 1;
X1 = zeros(N-(n_classes*num),2);
Y1 = zeros(N-(n_classes*num),1 );
    for i = 1:N

      if (lam(i,1)==0)
       X1(k,:) = u1(i,:);
       Y1(k,1) = (ground_truth(i,1));

       k =k+1;

      end
    end





X_train(:,p) = real(X(:,1)); %storing the first column of each p.
X_test (:,p) = real(X1(:,1));
end

Y_train = Y;
Y_test = Y1;
x_train = X_train;
y_train = Y_train;
x_test = X_test;
y_test = Y_test;


model = fitclinear(x_train, y_train);
prediction = predict(model, x_test);


final_yhat = prediction;


%testing accuracy

accuracy = (sum(final_yhat==y_test)/length(y_test))*100;
accuracy_total = accuracy_total + accuracy;
end
final_accuracy = accuracy_total/num_lab_sets;

                     end
                 end
             end
          end
    end
    accuracy = final_accuracy;
end
